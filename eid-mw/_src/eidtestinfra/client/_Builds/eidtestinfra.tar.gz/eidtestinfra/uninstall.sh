rm -rf /usr/share/eidtestinfra
