#include <unistd.h>
ssize_t get_parent_path(char *exec_path, size_t exec_path_size);
