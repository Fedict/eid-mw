#ifndef DIALOGS_H
#define DIALOGS_H

#define BEID_ASKPIN_DIALOG LIBEXECDIR "/beid-askpin"
#define BEID_CHANGEPIN_DIALOG LIBEXECDIR "/beid-changepin"
#define BEID_BADPIN_DIALOG LIBEXECDIR "/beid-badpin"
#define BEID_ASKACCESS_DIALOG LIBEXECDIR "/beid-askaccess"
#define BEID_SPR_ASKPIN_DIALOG LIBEXECDIR "/beid-spr-askpin"
#define BEID_SPR_CHANGEPIN_DIALOG LIBEXECDIR "/beid-spr-changepin"

#endif
