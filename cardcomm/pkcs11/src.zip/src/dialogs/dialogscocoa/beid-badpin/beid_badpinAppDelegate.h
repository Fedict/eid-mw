//
//  beid_badpinAppDelegate.h
//  beid-badpin
//
//  Created by Frank Mariën on 22/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@ interface beid_badpinAppDelegate:NSObject < NSApplicationDelegate >
{
	NSWindow *window;
}

@property(assign)
     IBOutlet NSWindow *window;

@end
