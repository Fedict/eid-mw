//
//  beid_badpinAppDelegate.m
//  beid-badpin
//
//  Created by Frank Mariën on 22/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "beid_badpinAppDelegate.h"

@implementation beid_badpinAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
