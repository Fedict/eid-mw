//
//  beid_askaccessAppDelegate.m
//  beid-askaccess
//
//  Created by Frank Mariën on 22/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "beid_askaccessAppDelegate.h"

@implementation beid_askaccessAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
