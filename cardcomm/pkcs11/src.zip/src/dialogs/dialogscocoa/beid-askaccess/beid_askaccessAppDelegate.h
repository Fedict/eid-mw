//
//  beid_askaccessAppDelegate.h
//  beid-askaccess
//
//  Created by Frank Mariën on 22/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@ interface beid_askaccessAppDelegate:NSObject < NSApplicationDelegate >
{
	NSWindow *window;
}

@property(assign)
     IBOutlet NSWindow *window;

@end
