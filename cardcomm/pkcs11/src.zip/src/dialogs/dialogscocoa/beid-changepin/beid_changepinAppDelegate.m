//
//  beid_changepinAppDelegate.m
//  beid-changepin
//
//  Created by Frank Mariën on 22/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "beid_changepinAppDelegate.h"

@implementation beid_changepinAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
