//
//  beid_askpinAppDelegate.m
//  beid-askpin
//
//  Created by Frank Mariën on 22/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "beid_askpinAppDelegate.h"

@implementation beid_askpinAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
