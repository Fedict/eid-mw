//
//  beid_spr_askpinAppDelegate.m
//  beid-spr-askpin
//
//  Created by Frank Mariën on 08/08/11.
//  Copyright 2011 FedICT. All rights reserved.
//

#import "beid_spr_changepinAppDelegate.h"

@implementation beid_spr_changepinAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	
}

@end
