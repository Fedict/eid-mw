//
//  beid_spr_askpinAppDelegate.h
//  beid-spr-askpin
//
//  Created by Frank Mariën on 08/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@ interface beid_spr_askpinAppDelegate:NSObject < NSApplicationDelegate >
{
	NSWindow *window;
}

@property(assign)
     IBOutlet NSWindow *window;

@end
