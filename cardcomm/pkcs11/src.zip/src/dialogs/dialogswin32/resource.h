//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DlgsWin32.rc
//
#define IDB_PIN                         106
#define IDB_ICO_INFO                    107
#define IDB_ICO_NOK                     108
#define IDB_ICO_QUESTION                109
#define IDB_ICO_WARNING                 110
#define IDB_KP_BTN                      112
#define IDB_KP_0                        116
#define IDB_KP_1                        117
#define IDB_KP_2                        118
#define IDB_KP_3                        119
#define IDB_KP_4                        120
#define IDB_KP_5                        121
#define IDB_KP_6                        122
#define IDB_KP_7                        123
#define IDB_KP_8                        124
#define IDB_KP_9                        125
#define IDB_KP_CE                       126
#define IDB_PINSIGN                     128

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
