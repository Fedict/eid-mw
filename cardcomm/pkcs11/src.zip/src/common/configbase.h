#include <wchar.h>
#include <stdbool.h>

#ifndef EIDMW_CONFIGBASE_H

#ifdef __cplusplus
extern "C" {
#endif
unsigned int eidmw_config_get_log_level(wchar_t *defaultLevel);
#ifdef __cplusplus
}
#endif
#endif
